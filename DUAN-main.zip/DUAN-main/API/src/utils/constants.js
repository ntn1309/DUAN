export const WHITELIST_DOMAINS = ['http://localhost:3000'];
